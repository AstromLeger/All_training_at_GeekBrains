const pokupki = `[

  {
    "Picture": "./img/Picture5.png",
    "h5": "ELLERY X M'O CAPSULE",
    "p": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "Picture": "./img/Picture6.png",
    "h5": "ELLERY X M'O CAPSULE",
    "p": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "Picture": "./img/Picture7.png",
    "h5": "ELLERY X M'O CAPSULE",
    "p": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "Picture": "./img/Picture8.png",
    "h5": "ELLERY X M'O CAPSULE",
    "p": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "Picture": "./img/Picture9.png",
    "h5": "ELLERY X M'O CAPSULE",
    "p": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  },
  {
    "Picture": "./img/Picture10.png",
    "h5": "ELLERY X M'O CAPSULE",
    "p": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price": "$52.00"
  }







]`




































































































