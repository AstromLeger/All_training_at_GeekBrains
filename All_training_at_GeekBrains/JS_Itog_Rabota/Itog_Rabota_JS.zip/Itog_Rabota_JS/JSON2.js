const Zakaz = `[
  {
    "img": "./img/Picture5.png",
    "h2": "ELLERY X M'O CAPSULE",
    "price": "$52.00",
    "color": "Blue",
    "size": "XL",
    "quantity": "1"
  },
  {
    "img": "./img/Picture6.png",
    "h2": "ELLERY X M'O CAPSULE",
    "price": "$52.00",
    "color": "Black",
    "size": "XL",
    "quantity": "1"
  },
  {
    "img": "./img/Picture7.png",
    "h2": "ELLERY X M'O CAPSULE",
    "price": "$52.00",
    "color": "BlueBlack",
    "size": "XL",
    "quantity": "1"
  },
  {
    "img": "./img/Picture8.png",
    "h2": "ELLERY X M'O CAPSULE",
    "price": "$52.00",
    "color": "VioletWhite",
    "size": "XL",
    "quantity": "1"
  },
  {
    "img": "./img/Picture9.png",
    "h2": "ELLERY X M'O CAPSULE",
    "price": "$52.00",
    "color": "Blue",
    "size": "XL",
    "quantity": "1"
  },
  {
    "img": "./img/Picture10.png",
    "h2": "ELLERY X M'O CAPSULE",
    "price": "$52.00",
    "color": "GreenWhite",
    "size": "XL",
    "quantity": "1"
  }
  ]`




























































